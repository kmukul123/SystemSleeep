All rights reserved

For using with .net 4.0 please rename SystemSleeep.Net 40.exe.config to SystemSleeep.exe.config

please contact simpliciti@outlook.com for anything, we appreciate your feedback.

For updates https://1drv.ms/f/s!AmaHAXM9ZhPhaYN972FkhyTLHO8